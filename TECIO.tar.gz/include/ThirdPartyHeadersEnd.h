#if defined(_MSC_VER)
  #pragma warning (pop)
#if (_MSC_VER > 1600)
	#pragma warning (pop)
#endif
#endif
